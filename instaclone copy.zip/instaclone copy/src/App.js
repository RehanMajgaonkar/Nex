// In App.js

import React from "react";

import Router from "./Pages/Router/Router";

const App = () => {
  return (
    <div>
      <Router />
    </div>
  );
};

export default App;
