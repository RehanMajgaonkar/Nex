// import { Modal, ModalBody, ModalContent,  ModalOverlay } from "@chakra-ui/react";
// import React from "react";
// import { BsThreeDots,BsBookmark,BsBookmarkFill, BsEmojiSmile } from "react-icons/bs";
// import { AiFillHeart, AiOutlineHeart } from "react-icons/ai";
// import { FaRegComment } from "react-icons/fa";
// import {  RiSendPlaneLine } from "react-icons/ri";
// import CommentCard from "./CommentCard";
// import "./CommentModal.css"

// const CommentModal=({onClose,isOpen,isSaved,isPostLiked,handlePostLike,handleSavePost})=>{
//     return (
//     <div >  
        
//       <Modal size={"4xl"} onClose={onClose} isOpen={isOpen} isCentered>
//         <ModalOverlay/>
//         <ModalContent>
          
          
//             <ModalBody>
//                 <div className=" flex h-[75vh] r"> 
//                     <div className="w-[45%] flex justify-center">
//                     <img className="max-h w-full" src="https://cdn.pixabay.com/photo/2023/09/14/16/17/soap-bubbles-8253276_1280.jpg" alt="" />
//                     </div>
//                     <div className=" w-[55%] pl-10 relative">
//                         <div className="flex justify-between item-center py-5">

                        
//                         <div className=" flex-item-center">
//                             <div>
//                                 <img className="w-9 h-9 rounded-full" src="https://cdn.pixabay.com/photo/2023/10/01/10/10/man-8287181_1280.jpg" alt="" />
//                             </div>
//                             <div className="ml-2">
//                                 <p>username</p>
//                             </div>
//                             </div>
//                             <BsThreeDots/>
                        
//                         </div>
//                         <hr />
//                         <div className="comment">
//                             {[1,1,1,1,].map(()=><CommentCard/>)}
//                         </div>
//                         <div className="absolute bottom-0 w-[90%]">
//                         <div className="flex justify-between items-center w-full  py-5">
//           <div className="flex items-center space-x-2">
//             {isPostLiked ? (
//               <AiFillHeart className="text-2xl hover:opacity-50 cursor-pointer text-red-600" onClick={handlePostLike} />
//             ) : (
//               <AiOutlineHeart className="text-2xl hover:opacity-50 cursor-pointer" onClick={handlePostLike} />
//             )}
//             <FaRegComment className="text-xl hover:opacity-50 cursor-pointer" />
//             <RiSendPlaneLine className="text-xl hover:opacity-50 cursor-pointer" />
//           </div>
//           <div className="cursor-pointer">
//             {isSaved ? (
//               <BsBookmarkFill className="text-xl hover:opacity-50 cursor-pointer" onClick={handleSavePost} />
//             ) : (
//               <BsBookmark onClick={handleSavePost} className="text-xl hover:opacity-50 cursor-pointer" />
//             )}
//           </div>
//         </div>
//         <div className="w-full py-2 ">
//           <p>10 Likes</p>
//           <p className="opacity-50 text-sm">1 day ago</p>
//         </div >

      
//         <div className="flex items-center w-full">
//           <BsEmojiSmile />
//           <input className="commentInput " type="text" placeholder="Add a Comment..." />
//         </div>
        
//         </div>
//                     </div>
//                 </div>
         

//             </ModalBody>
//         </ModalContent>


//       </Modal>
    
//     </div>
//     )
// }
// export default CommentModal
//above in correct but
// below is also giving proper answer

import { Modal, ModalBody, ModalContent, ModalOverlay } from "@chakra-ui/react";
import React from "react";
import { BsThreeDots, BsBookmark, BsBookmarkFill, BsEmojiSmile } from "react-icons/bs";
import { AiFillHeart, AiOutlineHeart } from "react-icons/ai";
import { FaRegComment } from "react-icons/fa";
import { RiSendPlaneLine } from "react-icons/ri";
import CommentCard from "./CommentCard";
import "./CommentModal.css";

const CommentModal = ({ onClose, isOpen, isSaved, isPostLiked, handlePostLike, handleSavePost }) => {
  return (
    <Modal size={"4xl"} onClose={onClose} isOpen={isOpen} isCentered>
      <ModalOverlay />
      <ModalContent className="modal-content">
        <ModalBody>
          <div className="flex h-screen">
            <div className="w-1/2">
              <img
                className="w-full h-full object-cover"
                src="https://cdn.pixabay.com/photo/2023/09/14/16/17/soap-bubbles-8253276_1280.jpg"
                alt=""
              />
            </div>
            <div className="w-1/2 p-4 flex flex-col backdrop-blur-md">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <img
                    className="w-10 h-10 rounded-full"
                    src="https://cdn.pixabay.com/photo/2023/10/01/10/10/man-8287181_1280.jpg"
                    alt=""
                  />
                  <div>
                    <p className="font-semibold">username</p>
                    <p className="text-gray-500 text-sm">1 day ago</p>
                  </div>
                </div>
                <BsThreeDots />
              </div>
              <hr className="mb-4" />
              <div className="flex-1 overflow-y-auto">
                {[1, 1, 1, 1, 1, 1, 1, 1].map((_, index) => (
                  <CommentCard key={index} />
                ))}
              </div>
              <div className="flex items-center mt-4">
                <BsEmojiSmile className="mr-2" />
                <input
                  className="flex-1 border rounded p-2 mr-2"
                  type="text"
                  placeholder="Add a Comment..."
                />
                <RiSendPlaneLine className="text-xl hover:opacity-50 cursor-pointer" />
              </div>
            </div>
          </div>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default CommentModal;
