import React from "react";
import SuggestionCard from "./SuggestionCard";

const HomeRight=()=>{
    return (
    <div >  
        <div>
            <div className="flex justify-between items-center">
                <div className="flex item-center">
                    <div>
                        <img className="w-12 h-12 rounded-full" src="https://media.istockphoto.com/id/1496615021/photo/natural-beauty-woman-relaxing-after-beauty-treatment.jpg?s=1024x1024&w=is&k=20&c=UGbViKZ9w-DEHwpPQt5PAkuhZkZL-Y_vkjZBEvNXywU=" alt="" />
                    </div>
                    <div className="ml-3">
                        <p>username</p>
                        <p className="opacity-50">UserName</p>
                    </div>
                </div>
                <div>
                    <p className="text-blue-700 font-semibold">
                        Switch
                    </p>
                </div>
                </div>
                <div className="space-y-5 mt-10">
                    {[1,1,1,1].map((item)=><SuggestionCard/>)}
                
            </div>
        </div>
    </div>
    )
}
export default HomeRight 