// import React from "react";
// import {TbCircleDashed} from "react-icons/tb"
// const ProfileUserDetails=()=>{
//     return (
//         <div className="py-10 w-full ">
//             <div className="flex item-center"> 
//             <div className="w-[15]">
//                 <img className=" w-32 h-32 rounded-full"src="https://cdn.pixabay.com/photo/2023/10/12/12/55/woman-8310751_1280.jpg" alt=""/>
//                 </div>

//         <br/> &nbsp;&nbsp;
//                 <div>
//                     <div className="flex space-x-10 items-center"> 
//                     <br/><br/>
//                         <p>username</p>
//                         <button>Edit Profile</button>
//                         <TbCircleDashed></TbCircleDashed>
//                     </div>
                    
//                     <div className="flex space-x-5">
//                         <div>
//                             <span className="font-semibold mr-2">10</span>
//                             <span>Post</span>
                            
//                         </div>
//                         <div>
//                             <span className="font-semibold mr-2">10</span>
//                             <span >Followers</span>
                            
//                         </div>
//                         <div>
//                             <span className="font-semibold mr-2">10</span>
//                             <span>Following</span>
                            
//                         </div>
//                       <div>
//                         <p className="font-semibold">Full Name</p>
//                         <p className="font-thin text-5m">Engineer @Infosys</p>
//                         <p className="font-thin text-5m">Bangalore!</p>
//                       </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     )
// }

// export default ProfileUserDetails

import React from "react";
import { TbCircleDashed } from "react-icons/tb";

const ProfileUserDetails = () => {
  return (
    <div className="py-10 w-full">
      <div className="flex items-center">
        <div className="w-[15]">
          <img
            className="w-32 h-32 rounded-full"
            src="https://cdn.pixabay.com/photo/2023/10/12/12/55/woman-8310751_1280.jpg"
            alt=""
          />
        </div>

        <div className="ml-4">
          <div className="flex items-center space-x-4">
            <p>username</p>
            <button>Edit Profile</button>
            <TbCircleDashed />
          </div>

          <div className="flex space-x-5 mt-2">
            <div>
              <span className="font-semibold mr-2">10</span>
              <span>Posts</span>
            </div>
            <div>
              <span className="font-semibold mr-2">10</span>
              <span>Followers</span>
            </div>
            <div>
              <span className="font-semibold mr-2">10</span>
              <span>Following</span>
            </div>
          </div>

          <div>
            <p className="font-semibold">Full Name</p>
            <p className="font-thin text-sm">Engineer @Infosys</p>
            <p className="font-thin text-sm">Bangalore!</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileUserDetails;
