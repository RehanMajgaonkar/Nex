// // // // // // // import React from "react";
// // // // // // // import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// // // // // // // import { RiVideoAddLine } from "react-icons/ri";
// // // // // // // import { BiBookmark } from "react-icons/bi";
// // // // // // // const RequestPostPart =()=>{
// // // // // // //     const tabs=[{
// // // // // // //         tab:"Post",
// // // // // // //         icon:<AiOutlineTable></AiOutlineTable>,
// // // // // // //         activeTab:""
// // // // // // //     },{
// // // // // // //         tab:"Reels", icon:<RiVideoAddLine></RiVideoAddLine>
// // // // // // //     },
// // // // // // //     {
// // // // // // //         tab:"Saved", icon:<BiBookmark></BiBookmark>
// // // // // // //     },
// // // // // // //     {
// // // // // // //         tab:"Tagged", icon:<AiOutlineUser></AiOutlineUser>
// // // // // // //     }

// // // // // // //     ]
// // // // // // //     return(
// // // // // // //         <div>
// // // // // // //             <div>
// // // // // // //                 {tabs.map((item)=> <div className="flex item-center cursor-pointer py-2 text-5m">
// // // // // // //                 <div>
// // // // // // //                     <p>{item.icon}</p>
// // // // // // //                     <p>{item.tab}</p>
// // // // // // //                 </div>)}

// // // // // // //             </div>

// // // // // // //         </div>
// // // // // // //     )
// // // // // // // }
// // // // // // // export default RequestPostPart


// // // // // // import React from "react";
// // // // // // import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// // // // // // import { RiVideoAddLine } from "react-icons/ri";
// // // // // // import { BiBookmark } from "react-icons/bi";

// // // // // // const RequestPostPart = () => {
// // // // // //   const tabs = [
// // // // // //     {
// // // // // //       tab: "Post",
// // // // // //       icon: <AiOutlineTable />,
// // // // // //     },
// // // // // //     {
// // // // // //       tab: "Reels",
// // // // // //       icon: <RiVideoAddLine />,
// // // // // //     },
// // // // // //     {
// // // // // //       tab: "Saved",
// // // // // //       icon: <BiBookmark />,
// // // // // //     },
// // // // // //     {
// // // // // //       tab: "Tagged",
// // // // // //       icon: <AiOutlineUser />,
// // // // // //     },
// // // // // //   ];

// // // // // //   return (
// // // // // //     <div>
// // // // // //       <div className="flex sapce-x-14 border-t realative">
// // // // // //         {tabs.map((item) => (
// // // // // //           <div className="flex items-center cursor-pointer py-2 text-5m">
// // // // // //             <div>
// // // // // //               <p>{item.icon}</p>
// // // // // //               <p>{item.tab}</p>
// // // // // //             </div>
// // // // // //           </div>
// // // // // //         ))}
// // // // // //       </div>
// // // // // //     </div>
// // // // // //   );
// // // // // // };

// // // // // // export default RequestPostPart;

// // // // // import React from "react";
// // // // // import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// // // // // import { RiVideoAddLine } from "react-icons/ri";
// // // // // import { BiBookmark } from "react-icons/bi";

// // // // // const RequestPostPart = () => {
// // // // //   const tabs = [
// // // // //     {
// // // // //       tab: "Post",
// // // // //       icon: <AiOutlineTable />,
// // // // //     },
// // // // //     {
// // // // //       tab: "Reels",
// // // // //       icon: <RiVideoAddLine />,
// // // // //     },
// // // // //     {
// // // // //       tab: "Saved",
// // // // //       icon: <BiBookmark />,
// // // // //     },
// // // // //     {
// // // // //       tab: "Tagged",
// // // // //       icon: <AiOutlineUser />,
// // // // //     },
// // // // //   ];

// // // // //   return (
// // // // //     <div>
// // // // //       <div className="flex space-x-14 border-t relative">
// // // // //         {tabs.map((item, index) => (
// // // // //           <div key={index} className="flex items-center cursor-pointer py-2 text-5m">
// // // // //             <div>
// // // // //               <p>{item.icon}</p>
// // // // //               <p className="ml-2">{item.tab}</p>
// // // // //             </div>
// // // // //           </div>
// // // // //         ))}
// // // // //       </div>
// // // // //     </div>
// // // // //   );
// // // // // };

// // // // // export default RequestPostPart;

// // // // import React from "react";
// // // // import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// // // // import { RiVideoAddLine } from "react-icons/ri";
// // // // import { BiBookmark } from "react-icons/bi";

// // // // const RequestPostPart = () => {
// // // //   const tabs = [
// // // //     {
// // // //       tab: "Post",
// // // //       icon: <AiOutlineTable />,
// // // //     },
// // // //     {
// // // //       tab: "Reels",
// // // //       icon: <RiVideoAddLine />,
// // // //     },
// // // //     {
// // // //       tab: "Saved",
// // // //       icon: <BiBookmark />,
// // // //     },
// // // //     {
// // // //       tab: "Tagged",
// // // //       icon: <AiOutlineUser />,
// // // //     },
// // // //   ];

// // // //   return (
// // // //     <div>
// // // //       <div className="flex border-t relative ">
// // // //         {tabs.map((item, index) => (
// // // //           <div key={index} className="flex items-center cursor-pointer py-2 text-5m space-x-2">
// // // //             {item.icon}
// // // //             <p>{item.tab}</p>
// // // //           </div>
// // // //         ))}
// // // //       </div>
// // // //     </div>
// // // //   );
// // // // };

// // // // export default RequestPostPart;

// // // import React, { useState } from "react";
// // // import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// // // import { RiVideoAddLine } from "react-icons/ri";
// // // import { BiBookmark } from "react-icons/bi";

// // // const RequestPostPart = () => {
// // //     const[activeTab,setActiveTab]=useState()
// // //   const tabs = [
// // //     {
// // //       tab: "Post",
// // //       icon: <AiOutlineTable />,
// // //     },
// // //     {
// // //       tab: "Reels",
// // //       icon: <RiVideoAddLine />,
// // //     },
// // //     {
// // //       tab: "Saved",
// // //       icon: <BiBookmark />,
// // //     },
// // //     {
// // //       tab: "Tagged",
// // //       icon: <AiOutlineUser />,
// // //     },
// // //   ];

// // //   return (
// // //     <div>
// // //       <div className="flex border-t relative">
// // //         {tabs.map((item) => (
// // //           <div  onClick={()=>setActiveTab(item.tab)} className={`${activeTab===item.tab?"border-t border-black" :"opacity-60"} lex items-center cursor-pointer py-2 text-5m space-x-2 ml-4`}>
// // //             {item.icon}
// // //             <p>{item.tab}</p>
// // //           </div>
// // //         ))}
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default RequestPostPart;
// // import React, { useState } from "react";
// // import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// // import { RiVideoAddLine } from "react-icons/ri";
// // import { BiBookmark } from "react-icons/bi";
// // import ReqUserPostCard from "../../Components/ProfileComponents/ReqUserPostCard";

// // const RequestPostPart = () => {
// //   const [activeTab, setActiveTab] = useState();
// //   const tabs = [
// //     {
// //       tab: "Post",
// //       icon: <AiOutlineTable />,
// //     },
// //     {
// //       tab: "Reels",
// //       icon: <RiVideoAddLine />,
// //     },
// //     {
// //       tab: "Saved",
// //       icon: <BiBookmark />,
// //     },
// //     {
// //       tab: "Tagged",
// //       icon: <AiOutlineUser />,
// //     },
// //   ];

// //   return (
// //     <div>
// //       <div className="flex border-t relative">
// //         {tabs.map((item) => (
// //           <div
// //             key={item.tab}
// //             onClick={() => setActiveTab(item.tab)}
// //             className={`${
// //               activeTab === item.tab ? "border-t border-black" : "opacity-60"
// //             } flex items-center cursor-pointer py-2 text-5m space-x-2 ml-4`}
// //           >
// //             {item.icon}
// //             <p>{item.tab}</p>
// //           </div>
// //         ))}
// //         <div>
// //             {[1,1,1].map((item)=><ReqUserPostCard/>)}
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default RequestPostPart;
// import React, { useState } from "react";
// import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
// import { RiVideoAddLine } from "react-icons/ri";
// import { BiBookmark } from "react-icons/bi";
// import ReqUserPostCard from "../../Components/ProfileComponents/ReqUserPostCard";

// const RequestPostPart = () => {
//   const [activeTab, setActiveTab] = useState();
//   const tabs = [
//     {
//       tab: "Post",
//       icon: <AiOutlineTable />,
//     },
//     {
//       tab: "Reels",
//       icon: <RiVideoAddLine />,
//     },
//     {
//       tab: "Saved",
//       icon: <BiBookmark />,
//     },
//     {
//       tab: "Tagged",
//       icon: <AiOutlineUser />,
//     }
//   ]

//   return (
//     <div>
//       <div className="flex border-t relative">
//         {tabs.map((item) => (
//           <div
//             key={item.tab}
//             onClick={() => setActiveTab(item.tab)}
//             className={`${
//               activeTab === item.tab ? "border-t border-black" : "opacity-60"
//             } flex items-center cursor-pointer py-2 text-5m space-x-2 ml-4`}
//           >
//             {item.icon}
//             <p>{item.tab}</p>
//           </div>
//         ))}
//       </div>

//       <div className="grid grid-cols-3 gap-4 mt-4">
//         {[1, 2, 3].map((item) => (
//           <ReqUserPostCard key={item} />
//         ))}
//       </div>
//     </div>
//   );
// };

// export default RequestPostPart;


import React, { useState } from "react";
import { AiOutlineTable, AiOutlineUser } from "react-icons/ai";
import { RiVideoAddLine } from "react-icons/ri";
import { BiBookmark } from "react-icons/bi";
import ReqUserPostCard from "../../Components/ProfileComponents/ReqUserPostCard";

const RequestPostPart = () => {
  const [activeTab, setActiveTab] = useState();
  const tabs = [
    {
      tab: "Post",
      icon: <AiOutlineTable />,
    },
    {
      tab: "Reels",
      icon: <RiVideoAddLine />,
    },
    {
      tab: "Saved",
      icon: <BiBookmark />,
    },
    {
      tab: "Tagged",
      icon: <AiOutlineUser />,
    },
  ];

  return (
    <div>
      <div className="flex border-t relative">
        {tabs.map((item) => (
          <div
            key={item.tab}
            onClick={() => setActiveTab(item.tab)}
            className={`${
              activeTab === item.tab ? "border-t border-black" : "opacity-60"
            } flex items-center cursor-pointer py-2 text-5m space-x-2 ml-4`}
          >
            {item.icon}
            <p>{item.tab}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4 mt-4">
        {[1, 2, 3,       ].map((item) => (
          <ReqUserPostCard key={item} />
        ))}
      </div>
    </div>
  );
};

export default RequestPostPart;
