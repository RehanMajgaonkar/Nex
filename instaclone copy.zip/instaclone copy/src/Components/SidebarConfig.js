import {AiFillCiCircle, AiFillCompass, AiFillHeart, AiFillHome, AiFillMessage, AiOutlineCompass, AiOutlineHeart, AiOutlineHome, AiOutlineMessage, AiOutlinePlusCircle, AiOutlineSearch} from 'react-icons/ai'
import {RiVideoFill,RiVideoLine} from "react-icons/ri"
import {CgProfile} from "react-icons/cg"

export const mainu=[
    {title:"Home",icon:<AiOutlineHome className='text-2xl mr-3'></AiOutlineHome>, iactiveIcon:<AiFillHome className='text-2xl mr-3'></AiFillHome>},
    {title:"Search",icon:<AiOutlineSearch className='text-2xl mr-3'></AiOutlineSearch>, iactiveIcon:<AiOutlineSearch className='text-2xl mr-3'></AiOutlineSearch>},
    {title:"Explore",icon:<AiOutlineCompass className='text-2xl mr-3'></AiOutlineCompass>, iactiveIcon:<AiFillCompass className='text-2xl mr-3'></AiFillCompass>},
    {title:"Reels",icon:<RiVideoLine className='text-2xl mr-3'></RiVideoLine>, iactiveIcon:<RiVideoFill className='text-2xl mr-3'></RiVideoFill>},
    {title:"Message",icon:<AiOutlineMessage className='text-2xl mr-3'></AiOutlineMessage>, iactiveIcon:<AiFillMessage className='text-2xl mr-3'></AiFillMessage>},
    {title:"Notification", icon:<AiOutlineHeart className='text-2xl mr-3'></AiOutlineHeart>,iactiveIcon:<AiFillHeart className='text-2xl mr-3'></AiFillHeart> },
    {title:"Create",icon:<AiOutlinePlusCircle className='text-2xl mr-3'></AiOutlinePlusCircle >, iactiveIcon:<AiFillCiCircle className='text-2xl mr-3'></AiFillCiCircle>},
    {title:"Profile",icon:<CgProfile className='text-2xl mr-3'></CgProfile>,iactiveIcon:<CgProfile className='text-2xl mr-3'></CgProfile>}
    

]