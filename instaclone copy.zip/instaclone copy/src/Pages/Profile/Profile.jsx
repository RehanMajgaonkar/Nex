import React from "react";
import ProfileUserDetails from "../../Components/ProfileComponents/ProfileUserDetails";
import RequestPostPart from "../../Components/ProfileComponents/RequestPostPart";
const Profile=()=>{
    return (
        <div className="px-20">
            <div >    
                <ProfileUserDetails/>
            </div>
            <div>
                <RequestPostPart/>
            </div>
        </div>
    )
}

export default Profile