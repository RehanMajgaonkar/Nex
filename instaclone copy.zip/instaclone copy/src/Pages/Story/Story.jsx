import React from "react";
import StoryViewer from "../../Components/StoryComponents/StoryViewer";
const Story =()=>{

    const story=[
        {
            Image:"https://images.pexels.com/photos/19153138/pexels-photo-19153138/free-photo-of-black-and-white-portrait-of-a-young-woman.jpeg"

        },
        {
            Image:"https://images.pexels.com/photos/19221481/pexels-photo-19221481/free-photo-of-a-black-and-white-photo-of-a-table-and-chairs-on-a-pier.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        },
        {
            Image:"https://images.pexels.com/photos/19211980/pexels-photo-19211980/free-photo-of-a-woman-in-a-long-black-dress-standing-on-a-box.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        },
        {
            Image:"https://images.pexels.com/photos/16835612/pexels-photo-16835612/free-photo-of-branches-of-a-dead-tree.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        }

    ]
    return (
        <div>
            <StoryViewer stories={story}/>

        </div>
    )
}
export default Story;